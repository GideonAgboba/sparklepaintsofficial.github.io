  
    <nav class="navbar navbar-extended nav-content white fixed-top" style="z-index: 1000;" style="position: fixed !important;top: 65px;margin-bottom: 0px !important;">
      <ul class="tabs tabs-transparent justify-content-center my-auto d-flex">
        <li class="tab">
          <a class="nav-link green-font store-nav-item" href="#emulsion">Emulsion <i class="fa fa-tint"></i></a>
        </li>
        <li class="tab">
          <a href="#texcote" class="nav-link green-font store-nav-item">Texcote <i class="fa fa-soundcloud"></i></a>
        </li>
        <li class="tab"><a href="#gloss" class="nav-link green-font store-nav-item">Gloss <i class="fa fa-yelp"></i></a></li>
      </ul>
      <ul>
        <?php include 'storenav-emulsion.php'; ?>
      </ul>
    </nav>