<?php
  $connect = mysqli_connect("localhost", "root", "", "products");
?>

            <h5 class="text-center text-white">Exerior emulsion/gloss <i class="fa fa-angle-down"></i></h5>
            <hr class="container">
<?php
      $query = "SELECT * FROM emulsion_exterior ORDER BY id ASC";
      $result = mysqli_query($connect, $query);
      if (mysqli_num_rows($result) >0) {
        while ( $row = mysqli_fetch_array($result)) {
    ?>
      <div class="green-body text-center">
          <div>
            <div class="col-md-4 p-2" ontouchstart="this.classList.toggle('hover');">
                <div class="container">
                    <div class="front" style="background-image: url(<?php echo $row["image"];  ?>)">
                      <img src="">
                        <div class="inner">
                            <p><?php echo $row["title"]; ?></p>
                        </div>
                    </div>
                    <div class="back">
                        <div class="inner">
                          <h2 class="text-white"><?php echo $row["description"]; ?></h2>
                          <i>Price: <s class="text-danger">N5,200</s></i>
                          <p>Our price: N<?php echo $row["price"]; ?></p>
                        </div>
                    </div>
                </div>
            </div>
          </div>
    </div>
    <?php
        }
      }
    ?>



            <h5 class="text-center text-white pt-3">Interior emulsion/gloss <i class="fa fa-angle-down"></i></h5>
            <hr class="container">
<?php
      $query = "SELECT * FROM emulsion_interior ORDER BY id ASC";
      $result = mysqli_query($connect, $query);
      if (mysqli_num_rows($result) >0) {
        while ( $row = mysqli_fetch_array($result)) {
    ?>
      <div class="green-body text-center">
          <div>
            <div class="col-md-4 p-2" ontouchstart="this.classList.toggle('hover');">
                <div class="container">
                    <div class="front" style="background-image: url(<?php echo $row["image"];  ?>)">
                      <img src="">
                        <div class="inner">
                            <p><?php echo $row["title"]; ?></p>
                        </div>
                    </div>
                    <div class="back">
                        <div class="inner">
                          <h2 class="text-white"><?php echo $row["description"]; ?></h2>
                          <i>Price: <s class="text-danger">N5,200</s></i>
                          <p>Our price: N<?php echo $row["price"]; ?></p>
                        </div>
                    </div>
                </div>
            </div>
          </div>
    </div>
    <?php
        }
      }
    ?>
