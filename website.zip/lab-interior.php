 <h1 class="text-white container-fluid text-center pt-3">Interior</h1>  
          <hr class="container">      
          <div class="row container-fluid">
            <div class="col" ontouchstart="this.classList.toggle('hover');">
                <div class="container">
                    <div class="front" style="background-image: url(imgs/lab-emulsion.jpg)">
                        <div class="inner">
                            <p>Emulsion</p>
                        </div>
                    </div>
                    <div class="back">
                        <div class="inner">
                          <h2 class="text-white">White and colored</h2>
                          <i>Price: <s class="text-danger">N5,200</s></i>
                          <p>Our price: N4,500</p>
                        </div>
                    </div>
                </div>
            </div>
              
          <div class="col-lg-6 mt-5">
            <i class="lab-qoutes"><q class="text-center">We offer finely mixed emulsion paints, with smooth texture and fine smell. Hover on the image to check our price and check our store to purchase.</q></i>
          </div>
          </div>
              
          <hr class="container">
          <div class="row container-fluid">
            
          <div class="col-lg-6 mt-5">
            <i class="lab-qoutes"><q class="text-center">We offer finely mixed Texcot paints, with smooth texture and fine smell. Hover on the image to check our price and check our store to purchase.</q></i>
          </div>

          
            <div class="col" ontouchstart="this.classList.toggle('hover');">
                <div class="container">
                    <div class="front" style="background-image: url(imgs/txt.jpg)">
                        <div class="inner">
                            <p>Texcote</p>
                        </div>
                    </div>
                    <div class="back">
                        <div class="inner">
                          <h2 class="text-white">White and colored</h2>
                          <i>Price: <s class="text-danger">N7,200</s></i>
                          <p>Our price: N6,000</p>
                        </div>
                    </div>
                </div>
            </div>
          </div>
                
          <hr class="container">
          <hr class="container">
          <div class="row container-fluid">
            <div class="col" ontouchstart="this.classList.toggle('hover');">
                <div class="container">
                    <div class="front" style="background-image: url(imgs/fh.jpg)">
                        <div class="inner">
                            <p>Gloss</p>
                        </div>
                    </div>
                    <div class="back">
                        <div class="inner">
                          <h2 class="text-white">White and colored</h2>
                          <i>Price: <s class="text-danger">N4,999</s></i>
                          <p>Our price: N4,500</p>
                        </div>
                    </div>
                </div>
            </div>
              
          <div class="col-lg-6 mt-5">
            <i class="lab-qoutes"><q class="text-center">We offer finely mixed emulsion paints, with smooth texture and fine smell. Hover on the image to check our price and check our store to purchase.</q></i>
          </div>
          </div>