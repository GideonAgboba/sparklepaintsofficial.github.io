  <nav class="navbar-extended green-body fixed-top" style="overflow:hidden;">
    <div class="nav-content home-navbar-sec2">
      <ul class="tabs tabs-transparent">
        <li class="tab">
          <a href="#test1" class="nav-link active white-text"><i class="fa fa-home"></i> Home</a>
        </li>
        <li class="tab">
          <a class="nav-link white-text" href="#test2"><i class="fa fa-flask"></i> Cataelogue</a>
        </li>
        <li class="tab">
          <a href="#test3" class="nav-link white-text"><i class="fa fa-archive"></i> Store</a>
        </li>
        <li class="tab"><a href="#test4" class="nav-link white-text"><i class="fa fa-question-circle"></i> About us</a></li>
      </ul>
    </div>
    </nav>



    