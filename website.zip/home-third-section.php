
      <div class="home-about-section green-body">
        <div class="home-about-section-container">
            <div class="row">
                <div class="col s4">
                    <div class="circle home-about-img">
                        <img src="imgs/wrap.jpg" class="rounded-circle">
                    </div>
                </div>
                <div class="col s8 text-center white-text ">
                    <q>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, laborum.
                    </q><br><br>
                        <a href="#" class="btn white green-font ">Contact Us</a>
                </div>
            </div>
        </div>
      </div>