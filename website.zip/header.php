<html>
<head>
<title>Sparkle</title>
	<link rel="stylesheet" type="text/css" href="css/materialize.min.css">
	<!-- <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"> -->
	<link rel="stylesheet" type="text/css" href="css/carousel.css">
	 
	<!-- JQuery -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<script src="css/bootstrap.min.js"></script>
	<script src="sparkle-min.css"></script>
	 
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
</head>
 
<body>
<div class="container"> 
   <div class="row">
      <div class="col-md-5">
	<a class="img-responsive logo" href="index.php"><img src="logo.png" /></a>
      </div>
   </div>
</div>