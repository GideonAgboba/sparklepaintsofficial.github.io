
      <footer class="home-footer green-body col-lg-12">
        <div class="text-white text-center">
          Sparklepaints.co@2018
          <p>Like our Social platforms@ <a href="#">Sparkle_paints</a></p>
          <div class="container footer-social">
            <i class="fa fa-facebook footer-social-i rounded-circle green-body white-text"></i>
            <i class="fa fa-instagram footer-social-i rounded-circle green-body white-text"></i>
            <i class="fa fa-twitter footer-social-i rounded-circle green-body white-text"></i>
          </div>
        </div>
      </footer>