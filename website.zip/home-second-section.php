 
  <h4 class="text-center green-font">Showcase <i class="fa fa-book"></i></h4>
  <hr class="container-fluid green-font">
  <div class="container-fluid gallery-section justify-content-center my-auto d-flex p-5">
<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css'><link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css'>
<style class="cp-pen-styles">img { max-height: 100% }
.swiper-container {
        width: 100%;
        height: 400px;
    }
    .swiper-slide {
        text-align: center;
        font-size: 18px;
        background: #fff;
        /* Center slide text vertically */
        display: -webkit-box;
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
        -webkit-box-align: center;
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
      /*width:90%;*/ 
    }</style></head><body>
<!-- Swiper -->
    <div class="swiper-container">
        <div class="swiper-wrapper">
            <div class="swiper-slide"><img src="imgs/gallery1.jpg" /></div>
            <div class="swiper-slide"><img src="imgs/gallery2.jpg"  /></div>
            <div class="swiper-slide"><img src="imgs/gallery3.jpg" /></div>
            <div class="swiper-slide"><img src="imgs/gallery4.jpg"  /></div>
            <div class="swiper-slide"><img src="imgs/gallery5.jpg" /></div>
            <div class="swiper-slide"><img src="imgs/gallery6.jpg"  /></div>
            <div class="swiper-slide"><img src="imgs/gallery7.jpg"  /></div>
            <div class="swiper-slide"><img src="imgs/gallery1.jpg"  /></div>
            <div class="swiper-slide"><img src="imgs/gallery1.jpg"  /></div>
            <div class="swiper-slide"><img src="imgs/gallery1.jpg"  /></div>
        </div>
        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
    </div>
<script src='//production-assets.codepen.io/assets/common/stopExecutionOnTimeout-b2a7b3fe212eaa732349046d8416e00a9dec26eb7fd347590fbced3ab38af52e.js'></script><script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script><script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.min.js'></script>
<script >var swiper = new Swiper('.swiper-container', {
        pagination: '.swiper-pagination',
        effect: 'coverflow',
        grabCursor: true,
        centeredSlides: true,
  spaceBetween: 0,
        //loop: true,
autoplay: 2500,
        autoplayDisableOnInteraction: false,
        slidesPerView: 4,
        coverflow: {
            rotate: 30,
            stretch: 0,
            depth: 100,
            modifier: 1,
            slideShadows : true
        }
    });

//# sourceURL=pen.js
</script>

          
        </div>